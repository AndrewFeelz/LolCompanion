# LolCompanion
Format: Android Application 
Description: Personal Project for Capstone Spring 2022 Class. This app is used to help new and old player alike to gain a better grasp on the popular game League of Legends and how to play with proficiency.
